package Serializer;

public class FNamesData {
    public String[] data;
}
