package Serializer;

public class Location {
    public String country;
    public String city;
    public float latitude;
    public float longitude;
}
