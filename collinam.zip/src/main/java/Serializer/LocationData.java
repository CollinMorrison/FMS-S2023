package Serializer;

public class LocationData {
    public Location[] data = new Location[0];
}
