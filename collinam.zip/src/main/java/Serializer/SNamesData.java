package Serializer;

public class SNamesData {
    public String[] data;
}
