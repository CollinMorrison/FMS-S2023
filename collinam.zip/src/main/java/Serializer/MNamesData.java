package Serializer;

public class MNamesData {
    public String[] data;
}
